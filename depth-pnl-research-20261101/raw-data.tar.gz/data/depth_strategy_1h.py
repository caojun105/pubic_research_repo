#!/usr/bin/env python3
"""Depth->direction test on the 1-hour Binance BTCUSDT capture.

Book: 5000-level snapshot + incremental depth, sequence-checked.
Bands: reference P = prevailing mid (best bid/ask). 6 bands of $1 each side:
  bid band j: (P-(j+1), P-j]      ask band j: [P+j, P+j+1)
Execution: causal. Signal at state t -> fill at first state with utc >= t + latency,
walking the real book. No fees (user assumption). Costs show up as spread + impact.
"""
import json, statistics as st, bisect
from pathlib import Path

D = Path('/home/ubuntu/reports/binance_depth5_ws/full_var_20261101T031206Z')
LAT_DEFAULT_MS = 100


def u(s):
    return int(round(float(s) * 1e8))


def replay():
    snap = json.loads((D / 'binance_snapshots.jsonl').read_text().splitlines()[0])
    s = snap['snapshot']
    bids = {u(p): u(q) for p, q in s['bids'] if u(q) > 0}
    asks = {u(p): u(q) for p, q in s['asks'] if u(q) > 0}
    last_uid = s['lastUpdateId']
    state = 'buffering'
    pending = []
    rej = {'stale': 0, 'gap': 0}
    out = []
    last_trade_px = None

    def snap_state(recv_ns, utc_ns, uid):
        bp, ap = max(bids), min(asks)
        P = (bp + ap) // 2
        bbands = [0] * 6
        abands = [0] * 6
        for p, q in bids.items():
            if p <= P:
                j = (P - p) // 100000000
                if j < 6:
                    bbands[j] += q
        for p, q in asks.items():
            if p >= P:
                j = (p - P) // 100000000
                if j < 6:
                    abands[j] += q
        covered = min(bids) <= P - 6 * 100000000 and max(asks) >= P + 6 * 100000000
        topb = sorted(bids.items(), key=lambda kv: -kv[0])[:80]
        topa = sorted(asks.items(), key=lambda kv: kv[0])[:80]
        return {'recv_ns': recv_ns, 'utc_ns': utc_ns, 'uid': uid,
                'bp': bp, 'ap': ap, 'bq': bids[bp], 'aq': asks[ap],
                'bbands': bbands, 'abands': abands, 'covered': covered,
                'bid1_btc': bids[bp] / 1e8, 'ask1_btc': asks[ap] / 1e8,
                'B': sum(bbands) / 1e8, 'A': sum(abands) / 1e8,
                'topb': topb, 'topa': topa,
                'spread_usd': (ap - bp) / 1e8}

    with open(D / 'binance_raw.jsonl') as f:
        for line in f:
            r = json.loads(line)
            d = r['data']
            recv = r['received']['local_mono_ns']
            utc_ns = r['received']['local_utc_ns']
            if r['stream'].endswith('@trade'):
                last_trade_px = u(d['p'])
                continue
            if state == 'buffering':
                pending.append(d)
                for i, e in enumerate(pending):
                    if e['U'] <= last_uid + 1 <= e['u']:
                        state = 'live'
                        pending = pending[i:]
                        break
                else:
                    continue
            else:
                pending.append(d)
            while pending:
                e = pending.pop(0)
                if e['u'] <= last_uid:
                    rej['stale'] += 1
                    continue
                if e['U'] > last_uid + 1:
                    rej['gap'] += 1
                    continue
                for p, q in e['b']:
                    pu, qu = u(p), u(q)
                    if qu == 0:
                        bids.pop(pu, None)
                    else:
                        bids[pu] = qu
                for p, q in e['a']:
                    pu, qu = u(p), u(q)
                    if qu == 0:
                        asks.pop(pu, None)
                    else:
                        asks[pu] = qu
                last_uid = e['u']
                if bids and asks:
                    out.append(snap_state(recv, utc_ns, last_uid))
    return out, rej, last_trade_px


def vwap(levels, qty_units):
    filled = 0
    cash = 0
    for p, q in levels:
        if filled >= qty_units:
            break
        take = min(q, qty_units - filled)
        cash += take * p
        filled += take
    if filled == 0:
        return 0, 0
    return filled, cash / filled


def stats(trades):
    if not trades:
        return {'n': 0, 'total': 0.0, 'win_pct': 0.0, 'avg': 0.0, 'mdd': 0.0,
                'hold_s': 0.0, 'avg_win': 0.0, 'avg_loss': 0.0}
    p = [t['pnl'] for t in trades]
    eq = peak = mdd = 0.0
    for x in p:
        eq += x
        peak = max(peak, eq)
        mdd = min(mdd, eq - peak)
    wins = [x for x in p if x > 0]
    losses = [x for x in p if x <= 0]
    return {'n': len(p), 'total': sum(p), 'win_pct': len(wins) / len(p) * 100,
            'avg': sum(p) / len(p), 'mdd': mdd,
            'hold_s': st.mean(t['hold_s'] for t in trades),
            'avg_win': st.mean(wins) if wins else 0.0,
            'avg_loss': st.mean(losses) if losses else 0.0}


def run(depths, b1_min, ratio_in, ratio_out, lat_ms=100, qty_btc=0.01,
        sustain_in_ms=500, sustain_out_ms=300, max_hold_s=30, reverse_ratio=None):
    lat = lat_ms * 1_000_000
    dts = [r['utc_ns'] for r in depths]
    qty_units = int(qty_btc * 1e8)
    in_since = out_since = None
    pos = None
    trades = []

    def fill_at(t_ns, levels_key):
        j = bisect.bisect_left(dts, t_ns + lat)
        if j >= len(depths):
            return None
        ex = depths[j]
        filled, px = vwap(ex[levels_key], qty_units)
        if filled < qty_units:
            return None
        return ex, px

    for r in depths:
        t = r['utc_ns']
        if pos is not None and t < pos['entry_ns']:
            continue                     # cannot act before entry actually filled
        if pos is None:
            ok = r['bid1_btc'] >= b1_min and r['A'] > 0 and r['B'] >= ratio_in * r['A']
            if not ok:
                in_since = None
                continue
            if in_since is None:
                in_since = t
            if t - in_since < sustain_in_ms * 1_000_000:
                continue
            got = fill_at(t, 'topa')     # buy walks asks
            if not got:
                continue
            ex, px = got
            pos = {'entry_px': px, 'entry_ns': ex['utc_ns'], 'qty': qty_units}
            in_since = None
            out_since = None
        else:
            held = t - pos['entry_ns']
            weak = r['bid1_btc'] < b1_min or (r['A'] > 0 and r['B'] / r['A'] <= ratio_out)
            rev = reverse_ratio is not None and r['A'] > 0 and r['A'] >= reverse_ratio * r['B']
            trigger = weak or rev
            if not trigger:
                out_since = None
                continue
            if out_since is None:
                out_since = t
            if (t - out_since) < sustain_out_ms * 1_000_000 and held < max_hold_s * 1e9:
                continue
            got = fill_at(t, 'topb')     # sell walks bids
            if not got:
                continue
            ex, px = got
            pnl = (px - pos['entry_px']) / 1e8 * qty_btc
            trades.append({'pnl': pnl, 'in_ns': pos['entry_ns'], 'out_ns': ex['utc_ns'],
                           'in_px': pos['entry_px'] / 1e8, 'out_px': px / 1e8,
                           'hold_s': (ex['utc_ns'] - pos['entry_ns']) / 1e9})
            pos = None
            out_since = None
    if pos is not None:
        got = fill_at(depths[-1]['utc_ns'], 'topb')
        if got:
            ex, px = got
            trades.append({'pnl': (px - pos['entry_px']) / 1e8 * qty_btc,
                           'in_ns': pos['entry_ns'], 'out_ns': ex['utc_ns'],
                           'in_px': pos['entry_px'] / 1e8, 'out_px': px / 1e8,
                           'hold_s': (ex['utc_ns'] - pos['entry_ns']) / 1e9,
                           'open_at_end': True})
    return trades


def main():
    depths, rej, last_px = replay()
    print(f'book states={len(depths)} rejected={rej}')
    t0, t1 = depths[0]['utc_ns'], depths[-1]['utc_ns']
    print(f'span {t0/1e9:.0f}..{t1/1e9:.0f}  ({(t1-t0)/1e9/60:.1f} min)')

    b1 = sorted(r['bid1_btc'] for r in depths)
    print('\n=== bid1 size (BTC) ===')
    for p in (10, 25, 50, 75, 90, 95, 99):
        print(f'  p{p:<2} = {b1[int(p/100*(len(b1)-1))]:6.3f}')
    for thr in (1, 2, 3, 5):
        print(f'  bid1>={thr}: {sum(1 for x in b1 if x>=thr)/len(b1)*100:5.1f}% of the hour')

    sp = sorted(r['spread_usd'] for r in depths)
    print(f'\nspread: median ${sp[len(sp)//2]:.4f}  p95 ${sp[int(.95*len(sp))]:.4f}')
    print(f'6x$1 band coverage complete: {sum(r["covered"] for r in depths)}/{len(depths)}')

    # --- predictive power, explicitly separating flat ---
    ts = [r['utc_ns'] for r in depths]
    mids = [(r['bp'] + r['ap']) / 2 for r in depths]

    def mid_at(ns):
        i = bisect.bisect_right(ts, ns)
        return mids[i - 1] if i else None

    print('\n=== prediction: mid direction after N seconds (up / flat / down) ===')
    hdr = f'{"signal":<28}' + ''.join(f'{h:>18}s' for h in (1, 5, 30, 60))
    print(hdr)
    tests = [('all states (baseline)', lambda r: True),
             ('bid1>=5 & B>A', lambda r: r['bid1_btc'] >= 5 and r['B'] > r['A']),
             ('bid1>=3 & B/A>=1.5', lambda r: r['bid1_btc'] >= 3 and r['A'] > 0 and r['B'] >= 1.5 * r['A']),
             ('B/A>=3', lambda r: r['A'] > 0 and r['B'] >= 3 * r['A']),
             ('ask: A/B>=2', lambda r: r['B'] > 0 and r['A'] >= 2 * r['B'])]
    for name, fn in tests:
        sel = [r for r in depths if fn(r)]
        if not sel:
            print(f'{name:<28} no samples')
            continue
        line = f'{name:<28}'
        for h in (1, 5, 30, 60):
            up = flat = dn = 0
            for r, m0 in zip(sel, [(r['bp'] + r['ap']) / 2 for r in sel]):
                m1 = mid_at(r['utc_ns'] + h * 1_000_000_000)
                if m1 is None:
                    continue
                if m1 > m0:
                    up += 1
                elif m1 < m0:
                    dn += 1
                else:
                    flat += 1
            n = up + flat + dn
            line += f'  {up/n*100:5.1f}/{flat/n*100:5.1f}/{dn/n*100:5.1f}%'
        print(line + f'   n={len(sel)}')
    print('  (up/flat/down as % of samples)')

    # --- parameter grid, IN-SAMPLE ONLY (first 40 min) ---
    split = t0 + 40 * 60 * 1_000_000_000
    ins = [r for r in depths if r['utc_ns'] < split]
    oos = [r for r in depths if r['utc_ns'] >= split]
    print(f'\n=== grid search, in-sample {len(ins)} states (first 40 min) ===')
    print(f'{"bid1>=":>7} {"ratio_in>=":>11} {"ratio_out<=":>11} {"n":>4} {"win%":>6} '
          f'{"pnl":>9} {"avg":>9} {"mdd":>8} {"hold":>6}')
    best = None
    for b1m in (0.5, 1.0, 2.0, 3.0):
        for rin in (1.2, 1.5, 2.0, 3.0):
            for rout in (1.0, 1.2):
                tr = run(ins, b1m, rin, rout)
                s = stats(tr)
                print(f'{b1m:>7} {rin:>11} {rout:>11} {s["n"]:>4} {s["win_pct"]:>6.1f} '
                      f'{s["total"]:>+9.4f} {s["avg"]:>+9.5f} {s["mdd"]:>8.3f} {s["hold_s"]:>6.1f}')
                if best is None or s['total'] > best[0]:
                    best = (s['total'], b1m, rin, rout, s)
    print(f'\nbest in-sample: bid1>={best[1]} ratio_in>={best[2]} ratio_out<={best[3]} '
          f'pnl={best[0]:+.4f} n={best[4]["n"]}')

    # --- out-of-sample ---
    b1m, rin, rout = best[1], best[2], best[3]
    tr_oos = run(oos, b1m, rin, rout)
    so = stats(tr_oos)
    tr_full = run(depths, b1m, rin, rout)
    sf = stats(tr_full)
    print('\n=== out-of-sample (last 20 min) ===')
    print(f'  n={so["n"]} win={so["win_pct"]:.1f}% pnl={so["total"]:+.4f} '
          f'avg={so["avg"]:+.5f} mdd={so["mdd"]:+.3f} hold={so["hold_s"]:.1f}s')
    print(f'  full hour (same params): n={sf["n"]} win={sf["win_pct"]:.1f}% '
          f'pnl={sf["total"]:+.4f}')

    # buy & hold benchmark, same capital
    bh = (depths[-1]['bp'] - depths[0]['ap']) / 1e8 * 0.01
    print(f'  buy&hold 0.01 BTC over hour: {bh:+.4f}')
    print(f'  hour price: {depths[0]["ap"]/1e8:.2f} -> {depths[-1]["bp"]/1e8:.2f} '
          f'({(depths[-1]["bp"]-depths[0]["ap"])/1e8/depths[0]["ap"]*1e8:+.1f} USD)')

    # --- latency sensitivity ---
    print('\n=== latency (best params, full hour) ===')
    for lat in (100, 300, 500, 1000):
        s = stats(run(depths, b1m, rin, rout, lat_ms=lat))
        print(f'  {lat:>4}ms n={s["n"]:>3} win={s["win_pct"]:5.1f}% pnl={s["total"]:+.4f}')

    # --- user's literal rule: bid1>=5 and B>A ---
    print('\n=== user rule as stated: bid1>=5 BTC & B>A ===')
    for rout in (1.0, 1.2):
        s = stats(run(depths, 5.0, 1.0, rout))
        print(f'  ratio_out<={rout}: n={s["n"]} win={s["win_pct"]:.1f}% pnl={s["total"]:+.4f} '
              f'avg={s["avg"]:+.5f} mdd={s["mdd"]:.3f} hold={s["hold_s"]:.1f}s')

    out = D / 'strategy_depth_1h'
    out.mkdir(exist_ok=True)
    with open(out / 'trades_best.csv', 'w') as f:
        f.write('entry_utc_ns,exit_utc_ns,entry_px,exit_px,hold_s,pnl\n')
        for t in tr_full:
            f.write(f"{t['in_ns']},{t['out_ns']},{t['in_px']:.2f},{t['out_px']:.2f},"
                    f"{t['hold_s']:.3f},{t['pnl']:.6f}\n")
    json.dump({'best': {'bid1_min': b1m, 'ratio_in': rin, 'ratio_out': rout},
               'in_sample': best[4], 'out_sample': so, 'full_hour': sf,
               'buy_hold': bh, 'states': len(depths), 'rejected': rej,
               'spread_median_usd': sp[len(sp)//2]},
              open(out / 'summary.json', 'w'), indent=2)
    print(f'\nwrote {out}')


if __name__ == '__main__':
    main()
